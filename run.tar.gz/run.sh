echo "Running da script"
